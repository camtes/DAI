f = open('../absolute-symlink.test_file.txt')
for line in f:
  print line,

