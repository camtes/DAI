#include <stdio.h>

int main() {
  printf("hello world static\n");
  return 0;
}
