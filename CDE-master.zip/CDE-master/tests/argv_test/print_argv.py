# test to make sure cde-exec interprets argv's in the exact same was as
# the original execution
import sys

print sys.argv
