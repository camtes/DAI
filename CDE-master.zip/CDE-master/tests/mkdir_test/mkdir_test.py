import os

try:
  os.mkdir('/home/pgbovine/testdir')
except OSError:
  pass

