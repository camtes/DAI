#!/bin/sh

readlink /proc/self/cwd

