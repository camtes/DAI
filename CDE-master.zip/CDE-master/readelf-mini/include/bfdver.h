#define BFD_VERSION_DATE 20100303
#define BFD_VERSION 220010000
#define BFD_VERSION_STRING  "(GNU Binutils) " "2.20.1.20100303"
#define REPORT_BUGS_TO "<http://www.sourceware.org/bugzilla/>"
