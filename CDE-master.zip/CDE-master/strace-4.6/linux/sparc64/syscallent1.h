#include "../sparc/syscallent1.h"
