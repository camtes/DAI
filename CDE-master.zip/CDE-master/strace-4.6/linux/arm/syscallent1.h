/* ARM specific syscalls */
	{ 5,	0,	printargs,		"SYS_0"			}, /* 0 */
	{ 5,	0,	printargs,		"breakpoint"		}, /* 1 */
	{ 5,	0,	printargs,		"cacheflush"		}, /* 2 */
	{ 5,	0,	printargs,		"usr26"			}, /* 3 */
	{ 5,	0,	printargs,		"usr32"			}, /* 4 */
	{ 5,	0,	printargs,		"set_tls"		}, /* 5 */
